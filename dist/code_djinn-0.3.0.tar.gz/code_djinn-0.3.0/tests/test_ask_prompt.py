from codedjinn.prompts.ask_prompt import build_ask_system_prompt


def test_build_ask_system_prompt_includes_missing_context_marker() -> None:
    prompt = build_ask_system_prompt(
        os_name="macOS",
        shell="zsh",
        cwd="/tmp",
        previous_context=None,
    )

    assert "<system_info>" in prompt
    assert "<environment>" in prompt
    assert 'missing="true"' in prompt


def test_build_ask_system_prompt_escapes_output_via_command_context() -> None:
    prompt = build_ask_system_prompt(
        os_name="macOS",
        shell="zsh",
        cwd="/tmp",
        previous_context={
            "command": "echo '<tag>'",
            "output": "line1\n<tag>\nline3",
            "exit_code": 0,
        },
    )

    assert "<command_context>" in prompt
    assert "&lt;tag&gt;" in prompt

