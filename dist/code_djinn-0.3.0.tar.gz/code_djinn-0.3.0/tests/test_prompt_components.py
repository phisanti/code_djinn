import unittest

from codedjinn.prompts.prompt_components import build_command_context, build_environment


class TestPromptComponents(unittest.TestCase):
    def test_build_environment_includes_working_directory(self) -> None:
        cwd = "/tmp/project"
        xml = build_environment(cwd)

        self.assertIn("<environment>", xml)
        self.assertIn("<working_directory>", xml)
        self.assertIn(cwd, xml)

    def test_build_command_context_escapes_output(self) -> None:
        xml = build_command_context(
            {
                "command": "echo '<tag> & stuff'",
                "exit_code": 0,
                "output": "line1\n<tag>\n&\nline4",
            }
        )

        self.assertIn("<command_context>", xml)
        self.assertIn("&lt;tag&gt;", xml)
        self.assertIn("&amp;", xml)
        self.assertNotIn("<output>\nline1\n<tag>", xml)


if __name__ == "__main__":
    unittest.main()
