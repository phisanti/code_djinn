"""Test system prompt structure and XML formatting.

Focus on:
- Prompt includes required sections
- XML special characters are escaped
- Context is included when provided
"""

import pytest
from codedjinn.prompts.system_prompt import build_system_prompt


@pytest.fixture
def basic_prompt_args():
    """Common arguments for building prompts."""
    return {
        "os_name": "macOS",
        "shell": "zsh",
        "cwd": "/Users/test/project"
    }


@pytest.fixture
def sample_context():
    """Sample command context for testing."""
    return {
        'command': 'git branch -a',
        'output': '  main\n  feature-x\n* current-branch',
        'exit_code': 0
    }


class TestPromptStructure:
    """Test that prompts include required XML sections."""

    def test_prompt_includes_required_sections(self, basic_prompt_args):
        """Prompt should include all required top-level sections."""
        prompt = build_system_prompt(**basic_prompt_args)

        required_sections = [
            '<system_info>',
            '<environment>',
            '<working_directory>',
            '<instructions>',
        ]

        for section in required_sections:
            assert section in prompt, f"Missing required section: {section}"

    def test_prompt_without_context_excludes_command_section(self, basic_prompt_args):
        """When no context provided, command_context should not appear."""
        prompt = build_system_prompt(**basic_prompt_args)
        assert '<command_context>' not in prompt

    def test_prompt_with_context_includes_command_section(self, basic_prompt_args, sample_context):
        """When context provided, should include command_context section."""
        prompt = build_system_prompt(**basic_prompt_args, previous_context=sample_context)

        assert '<command_context>' in prompt
        assert '<previous_command>' in prompt
        assert '<executed>' in prompt
        assert '<exit_code>' in prompt
        assert '<output>' in prompt


class TestContextInclusion:
    """Test that command context is properly included in prompts."""

    def test_context_includes_command(self, basic_prompt_args, sample_context):
        """Context should include the executed command."""
        prompt = build_system_prompt(**basic_prompt_args, previous_context=sample_context)
        assert 'git branch -a' in prompt

    def test_context_includes_output(self, basic_prompt_args, sample_context):
        """Context should include command output."""
        prompt = build_system_prompt(**basic_prompt_args, previous_context=sample_context)
        assert 'current-branch' in prompt

    def test_context_includes_exit_code(self, basic_prompt_args, sample_context):
        """Context should include exit code."""
        prompt = build_system_prompt(**basic_prompt_args, previous_context=sample_context)
        assert '<exit_code>0</exit_code>' in prompt


class TestXMLEscaping:
    """Test that XML special characters are properly escaped."""

    def test_xml_special_chars_escaped(self, basic_prompt_args):
        """XML special characters in context should be escaped."""
        context = {
            'command': 'echo "hello & goodbye" > file.txt',
            'output': 'Output with <tags> and & ampersands',
            'exit_code': 0
        }

        prompt = build_system_prompt(**basic_prompt_args, previous_context=context)

        # Verify escaping
        assert '&amp;' in prompt
        assert '&lt;' in prompt or '&gt;' in prompt
        # Raw tags should not appear unescaped
        assert 'Output with <tags>' not in prompt

    def test_unescaped_tags_not_present(self, basic_prompt_args):
        """Raw < and > in content should be escaped."""
        context = {
            'command': 'test',
            'output': '<dangerous>content</dangerous>',
            'exit_code': 0
        }

        prompt = build_system_prompt(**basic_prompt_args, previous_context=context)
        # Should be escaped, not raw
        assert '<dangerous>' not in prompt or '&lt;dangerous&gt;' in prompt
