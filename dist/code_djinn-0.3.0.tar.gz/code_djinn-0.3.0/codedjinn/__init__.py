"""Code Djinn package initializer."""
