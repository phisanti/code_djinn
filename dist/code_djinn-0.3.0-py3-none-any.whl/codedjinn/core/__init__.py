"""Core modules for Code Djinn."""
