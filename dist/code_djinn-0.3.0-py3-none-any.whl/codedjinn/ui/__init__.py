"""UI layer for the new Typer-based CLI."""
